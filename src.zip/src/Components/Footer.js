import React from 'react';

const Footer = () => {
  return (
    <div className='footer'>
        <p>©2024 DP World DAR. All rights reserved</p>

    </div>
  );
}

export default Footer;
