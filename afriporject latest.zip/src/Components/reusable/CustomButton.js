import React from 'react';


const Custombutton = ({data}) => {
  return (
    <>
       <button className='button' type='submit'>{data}</button>
       </>
  );
}

export default Custombutton;
